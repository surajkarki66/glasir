# 🔥 mern-auth-template-tutorial 🔥

Hey devs! This is the source code for my completed MERN stack authentication youtube tutorial: https://www.youtube.com/playlist?list=PLJM1tXwlGdaf57oUx0rIqSW668Rpo_7oU

Feel free to use this as a starting template for your own projects.
